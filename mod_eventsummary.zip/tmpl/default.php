<?php
/**
 * Displays a responsive table of event registration summaries.
 *
 * @package    Event Summary
 * @author     Frans Stuurman
 * @copyright  Frans Stuurman
 * @license    MIT see LICENSE
 */

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

// Load language file for table headers
Text::load('mod_eventsummary.ini', JPATH_SITE . '/modules/mod_eventsummary');

?>
<style>
    .eventsummary-table-wrapper {
        overflow-x: auto;
    }
    .eventsummary-table {
        width: 100%;
        border-collapse: collapse;
    }
    .eventsummary-table th,
    .eventsummary-table td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    .eventsummary-table th {
        background-color: #f2f2f2;
    }
</style>

<div class="eventsummary-table-wrapper">
    <table class="eventsummary-table">
        <thead>
            <tr>
                <th><?php echo Text::_('MOD_EVENTSUMMARY_TABLE_HEADER_EVENT'); ?></th>
                <th><?php echo Text::_('MOD_EVENTSUMMARY_TABLE_HEADER_DATE'); ?></th>
                <th><?php echo Text::_('MOD_EVENTSUMMARY_TABLE_HEADER_REGISTRATIONS'); ?></th>
                <th><?php echo Text::_('MOD_EVENTSUMMARY_TABLE_HEADER_CHECKED_IN'); ?></th>
                <th><?php echo Text::_('MOD_EVENTSUMMARY_TABLE_HEADER_NOT_CHECKED_IN'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($eventData)) : ?>
                <?php foreach ($eventData as $event) : ?>
                    <tr>
                        <td data-label="<?php echo Text::_('MOD_EVENTSUMMARY_TABLE_HEADER_EVENT'); ?>"><?php echo htmlspecialchars($event->title, ENT_COMPAT, 'UTF-8'); ?></td>
                        <td data-label="<?php echo Text::_('MOD_EVENTSUMMARY_TABLE_HEADER_DATE'); ?>"><?php echo JHtml::_('date', $event->event_date, 'd-m-Y'); ?></td>
                        <td data-label="<?php echo Text::_('MOD_EVENTSUMMARY_TABLE_HEADER_REGISTRATIONS'); ?>"><?php echo (int)$event->current_registrations; ?></td>
                        <td data-label="<?php echo Text::_('MOD_EVENTSUMMARY_TABLE_HEADER_CHECKED_IN'); ?>"><?php echo (int)$event->checked_in; ?></td>
                        <td data-label="<?php echo Text::_('MOD_EVENTSUMMARY_TABLE_HEADER_NOT_CHECKED_IN'); ?>"><?php echo (int)$event->not_checked_in; ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="5"><?php echo Text::_('MOD_EVENTSUMMARY_NO_EVENTS_FOUND'); ?></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>